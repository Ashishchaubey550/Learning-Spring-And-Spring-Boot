package com.Ashish.BootProject2_StrategyDP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootProject2StrategyDpApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootProject2StrategyDpApplication.class, args);
	}

}
