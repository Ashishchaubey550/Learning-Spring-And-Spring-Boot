package com.Ashish.BootProject2_StrategyDP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootProject2StrategyDpApplicationTests {

	@Test
	void contextLoads() {
	}

}
